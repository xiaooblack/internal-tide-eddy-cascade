# Coarsened 15 m drifter and ADCP observations

This is a local review copy prepared for assessment before any public release.
Data-owner approval for publication has not been established. Real coarsened
geographical coordinates and available calendar dates are retained; these data
are not anonymized. Coarsening alone is not a determination of release eligibility.

## Contents and variables

- `drifters/`: 92 NetCDF files, one per input drifter.
- `adcp/`: 11 NetCDF files, one per input section.
- Both contain `lon`, `lat`, `u`, `v`, and nominal `depth = 15 m`.
- Drifters contain a one-dimensional `time` day label.
- ADCP sections contain a `point` index and a scalar `survey_date` where available.
- Velocity units are m/s; longitude/latitude units are degrees east/north.
- Coordinate and velocity variables use packed 16-bit integers with a scale factor
  of 0.1. Standard NetCDF readers, including MATLAB `ncread`, decode them automatically.
  Integer storage prevents retaining extra decimal precision underneath display rounding.
- `manifest.csv` records only information from the coarsened files.

## Coarsening

Drifter input time is seconds since 2000-01-01, as established from the original
processing scripts. All positions and velocity components are averaged together
within non-overlapping calendar days. A daily record requires at least 24 valid
15-minute samples (6 nominal sampling hours); short edge fragments are omitted.
The published day is a bin label, not the original measurement time or the exact
mean sampling time. No original positions, exact timestamps, bounds of actual
coverage, accelerations, or unrounded velocity variables are included.

ADCP samples are averaged within non-overlapping 10 km blocks of cumulative
along-track distance. Blocks with fewer than 10 input samples are omitted.
No interpolation fills short end fragments, and exact along-track distances are
not retained. The nominal input spacing was approximately 0.5 km.

After averaging, both data types have longitude and latitude rounded to 0.1 degree
(approximately 10 km in this region) and each velocity component rounded to 0.1 m/s.
These are coarse block means. Positions and velocities are independently rounded,
so a difference of released positions need not equal the released mean velocity.
Coarse displacement rates can still be estimated, but the original 15-minute
tracks and velocity fluctuations are not included in this package.

The source files do not specify their time zone; the source calendar convention
is retained without inventing a time-zone conversion. The ADCP files do not
contain valid per-point timestamps. For nine sections only a start date can be
recovered; it is reduced to day precision. Missing dates remain missing in:
- `adcp/adcp_section_02_coarse_15m.nc`
- `adcp/adcp_section_08_coarse_15m.nc`

## Interpretation

This product retains broad trajectory/section geometry and coarse mean currents.
It differs from the uncoarsened observations used for the manuscript calculations.
It should not be described as reproducing the manuscript's 1–100 km structure
functions, small-scale energy transfer, or original temporal variability.
No claim of equivalence to the analysis-resolution data is made.

All provided source files were processed. The drifter files include records beyond
the main manuscript analysis period. Readers should use `manifest.csv` to identify
the retained date coverage; this package does not imply all retained dates were
used in the manuscript's structure functions.

No source file names, instrument serial identifiers, source folder paths, original
global attributes, or ancillary input variables are copied into the output files.
Generic identifiers label the coarsened files. These label changes do not make
real coordinates or dates anonymous.

## Example in MATLAB

```matlab
lon = ncread('drifters/drifter_001_coarse_15m.nc','lon');
lat = ncread('drifters/drifter_001_coarse_15m.nc','lat');
u   = ncread('drifters/drifter_001_coarse_15m.nc','u');
v   = ncread('drifters/drifter_001_coarse_15m.nc','v');
t   = datetime(2000,1,1) + days(ncread('drifters/drifter_001_coarse_15m.nc','time'));
plot(lon,lat,'.-'); xlabel('Longitude'); ylabel('Latitude');
```
